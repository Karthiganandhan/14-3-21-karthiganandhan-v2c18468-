class Excepex { 
  
    public static void main(String args[]) 
    { 
       
        try { 
  
        	 int a1[] = { 1, 2, 3, 4, 5 }; 
        	  
             System.out.println(a1[6]); 
  
            try { 
            	 int a[] = { 1, 2, 3, 4, 5 }; 
            	  
                
               int x = a[2] / 0; 
               System.out.println(x); 
               
            } 
            catch (ArithmeticException e2) { 
                System.out.println("division by zero is not possible"); 
            } 
        } 
        catch (ArrayIndexOutOfBoundsException e1) { 
            System.out.println("ArrayIndexOutOfBoundsException"+e1); 
            System.out.println("Element at such index does not exists"); 
        } 
    } 
   
} 