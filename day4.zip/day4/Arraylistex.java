import java.util.ArrayList;

class Employee {
   private String name;
   private Integer id;

   public Employee(String name, Integer id) {
      this.name = name;
      this.id = id;
   }

   public String getName() {
      return name;
   }

   public void setName(String name) {
      this.name = name;
   }

   public Integer getId() {
      return id;
   }

   public void setId(Integer id) {
      this.id = id;
   }

   @Override
   public String toString() {
      return "{" +
      "name='" + name+ '\'' +
      ", id=" + id +
      '}';
   }
}

public class Arraylistex {
   public static void main(String[] args) {
      ArrayList<Employee> resource = new ArrayList<Employee>();
      resource.add(new Employee("Manager", 1));
      resource.add(new Employee("Team Lead", 2));
      resource.add(new Employee("Engineer", 3));
      resource.add(new Employee("Trainee", 4));

      System.out.println("Employee List before sorting: " + resource);

      resource.remove(1);
      
      resource.add(new Employee("Team Lead", 2));
      
      System.out.println("Employee List before sorting: " + resource);
     

      
    
   }
}
