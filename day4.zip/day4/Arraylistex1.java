import java.util.ArrayList;

public class Arraylistex1 {
   public static void main(String[] args) {
      ArrayList<Integer> id = new ArrayList<Integer>();
      id.add(1);
      id.add(2);
      id.add(3);
      id.add(4);
      id.add(5);
     

      
      
      ArrayList<String> name = new ArrayList<String>();
      name.add("nandha");
      name.add("billa");
      name.add("david");
      name.add("surya");
      name.add("siva");
      java.util.Iterator<Integer> bookIterator = id.iterator();
      while (bookIterator.hasNext()) {
         System.out.println("id:"+bookIterator.next());}
      
         java.util.Iterator<String> bookIterator1 = name.iterator();
         
		while (bookIterator1.hasNext()) {
            System.out.println("name:"+bookIterator1.next());
		}
            System.out.println("***************remove***********");
            
            name.remove(1);
           
                System.out.println(id);
                System.out.println(name);
            System.out.println("***************add***********"); 
            
            
            name.add(1,"billa");
            System.out.println(id);
                System.out.println(name);
   }
}

