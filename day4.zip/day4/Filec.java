import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Filec {
   public static void main(String args[]) throws IOException {
      
      String filePath = "D://input.txt";
      
      Scanner sc = new Scanner(new File(filePath));
     
      StringBuffer buffer = new StringBuffer();
      
      while (sc.hasNextLine()) {
         buffer.append(sc.nextLine()+System.lineSeparator());
      }
      String fileContents = buffer.toString();
      System.out.println("Contents of the file: "+fileContents);
      
      sc.close();
      String oldLine = "Java is object oriented programming language";
      String newLine = "Python is easy interpreted and oops";
      
      fileContents = fileContents.replaceAll(oldLine, newLine);
      try (//instantiating the FileWriter class
	FileWriter writer = new FileWriter(filePath)) {
		System.out.println("");
		  System.out.println("new data: "+fileContents);
		  writer.append(fileContents);
		  writer.flush();
	}
   }
}